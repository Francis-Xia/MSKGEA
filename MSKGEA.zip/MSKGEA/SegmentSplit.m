function Split = SegmentSplit(Population,Problem,wid)
% function [Segment,Split] = SegmentSplit(Population,Problem,wid)
%%Segment��ÿ���еĸ��壬split �Ǽ�¼ÿ�����������Ǹ���
%   �˴���ʾ��ϸ˵��
    N  = size(Population.decs,1);
    Split = zeros(N,1);
    for i = 1:N
        QUYU = floor((Population(i).decs-Problem.lower)./wid)+1;
        QUYU = min(QUYU,2);
        if Problem.D==2
            ColIndex = (QUYU(:,2)-1).*2+QUYU(:,1);
        elseif Problem.D==3
            ColIndex = (QUYU(:,3)-1).*2*2+(QUYU(:,2)-1).*2+QUYU(:,1);
        else
            ColIndex = (QUYU(:,4)-1).*2*2*2+(QUYU(:,3)-1).*2*2+(QUYU(:,2)-1).*2+QUYU(:,1);
        end
        Split(i) = ColIndex;
    end
end

