classdef MSKGEA < ALGORITHM
    % <multi> <real> <multimodal>
    methods
        function main(Algorithm,Problem)
            %% Parameter setting
     %       kappa = Algorithm.ParameterSet(0.05);
            t_gen = ceil((Problem.maxFE/Problem.N)*0.7);
            t_gen1 = ceil((Problem.maxFE/Problem.N)*0.72);
            %% Generate random population
            Population = Problem.Initialization();
            %% 分区
            wid = (Problem.upper - Problem.lower)./2; 
            state = 1;
            [~,Fitness] = EnvironmentalSelection(Population,Problem.N,Problem,wid,state);
%            [Archive,Fdnk] = UpdateArc(Population,[],Problem,wid,state);          
            %% Optimization
            while Algorithm.NotTerminated(Population)
                if Problem.FE/Problem.N>=t_gen1
                    state = 3;  %独立进化
                else
                    if Problem.FE/Problem.N < t_gen
                        state = 1;  %分区
                    else
                        state = 2;  %找出主种群
                    end
                end
                if state == 1  %stage 1 : the mating selection in which parents are selected from population instead of archive
                     MatingPool = TournamentSelection(2,Problem.N,Fitness);%选十分之一N个父代
                     Offspring  = OperatorGA(Problem,Population(MatingPool));%产生十分之一N个子代
                     [Population,Fitness] = EnvironmentalSelection([Population,Offspring],Problem.N,Problem,wid,state);
                      MainPop = Population;  %第一阶段所留下的解 
                else 
                    if state == 2  % stage 2: 找出主种群
                        MatingPool = TournamentSelection(2,Problem.N,Fitness);
                        Offspring  = OperatorGA(Problem,Population(MatingPool));
                        [Population,Fitness] = EnvironmentalSelection([Population,Offspring],Problem.N,Problem,wid,state);
                        AssistPop =  Population;
                      b = AssistPop.decs;
%                        scatter(b(:,1),b(:,2));
                      
                       Split = SegmentSplit(AssistPop,Problem,wid);
                        for i=1:2^Problem.D
                            cluster = find(Split==i);
                            if ~isempty(cluster)
                               if length(cluster)==1
                                   r(i) = 0;
                               else
                                   Distance = sort(pdist2(AssistPop(cluster).decs,AssistPop(cluster).decs),2); 
                                   r(i) = (min(Distance(:,2))+ max(Distance(:,end)))/2;
                               end
                            end
                        end
                        radius = max(r);
                        
                        LegalFQ = unique(Split);
                        Distance = sort(pdist2(MainPop.decs,AssistPop.decs),2);
                        Population = MainPop(Distance(:,1)<radius);
%                         ExtraPop = setdiff(AssistPop,Population);  %%填补用的解
                        Population = [Population setdiff(AssistPop,Population)];
                        num = Problem.N-length(Population);
                        if num>0
                            PopDec = unifrnd(repmat(Problem.lower,num,1),repmat(Problem.upper,num,1));
                           % Population1 = SOLUTION(PopDec);
                              Population1=Problem.Evaluation(PopDec);
                            Population = [Population Population1];
                        end
                        Split = SegmentSplit(Population,Problem,wid);
                        n=length(Population);
                        Fitness = inf(n,1);
                        for i=1:2^Problem.D
                            cluster = find(Split==i);
                            if ~isempty(cluster) && ismember(i,LegalFQ)
                                Fitness(cluster)  = CalFitness(Population(cluster).objs,Population(cluster).decs);
                            end
                        end
%                          b = Population.decs;
                    else                        % stage 3: 独立进化                       
                         p1 = TournamentSelection(2,round(Problem.N/10),Fitness);
                        Maxd = max(Population.decs,[],1);
                        Mind = min(Population.decs,[],1);
                        nn = size(Population.decs,1);
                        PopDec = (Population.decs-repmat(Mind,nn,1))./repmat(Maxd-Mind,nn,1);
                        dist = pdist2(PopDec(p1,:),PopDec);
                        [~,so] = sort(dist,2);
                        so = so(:,2:round(Problem.N/20)+1);%p2的范围
                        index = randi(round(Problem.N/20),round(Problem.N/10),1);
                        p2 = so((index-1)*round(Problem.N/10)+(1:round(Problem.N/10))');
                        parents = [Population(p1) Population(p2)];
                        %Offspring = OperatorGAhalf(parents);
                        Offspring =OperatorGAhalf(Problem,parents);
%                         c = Offspring.decs;
                     [Population,Fitness] = Stage3EnvironmentalSelection([Population,Offspring],Problem.N,Problem,wid,LegalFQ);
                    end
                end
            end
        end
    end
end