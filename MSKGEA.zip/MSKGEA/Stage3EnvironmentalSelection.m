function [Population,Fitness] = Stage3EnvironmentalSelection(Population,N,Problem,wid,LegalFQ)
    %% calculate the weighted indicator value of each solution
    
    Split = SegmentSplit(Population,Problem,wid);
   % Next = ismember(Split,LegalFQ);
    [n,D] = size(Population.decs);
    Fitness = inf(n,1);
    for i=1:2^D
        if ~ismember(i,LegalFQ)
            continue;
        end
        cluster = find(Split==i);
        if ~isempty(cluster)
            Fitness(cluster)  = CalFitness(Population(cluster).objs,Population(cluster).decs);
        end
    end
    
    Next = Fitness < 1;
    if sum(Next) < N
        [~,Rank] = sort(Fitness);
        Next(Rank(1:N)) = true;
    elseif sum(Next) > N
        Del  = Truncation(Population(Next).decs,sum(Next)-N);
        Temp = find(Next);
        Next(Temp(Del)) = false;
    end
    Population = Population(Next);
    Fitness = Fitness(Next);
end

function Del = Truncation(PopDec,K)
% Select part of the solutions by truncation

N = size(PopDec,1);

%% Calculate the distance between each two solutions
%  DecDistance = inf(N);
Maxd = max(PopDec,[],1);
Mind = min(PopDec,[],1);
PopDec = (PopDec-repmat(Mind,N,1))./repmat(Maxd-Mind,N,1);

DecDistance = pdist2(PopDec,PopDec);%两个个体间的距离
DecDistance(logical(eye(length(DecDistance)))) = inf;%自己到自己的距离无限大
%     DecDistance = sort(DecDistance,2);%每一行从小到大排序，每一行就是各个点到该点的距离

%% Truncation
Del = false(1,N);
while sum(Del) < K
    Remain   = find(~Del);
    Distance = DecDistance(Remain,Remain);
    Distance = sort(Distance,2);%每一行从小到大排序，每一行就是各个点到该点的距离
    Temp     = sort(Distance,2);
    [~,Rank] = sortrows(Temp);
    Del(Remain(Rank(1))) = true;
end
end
