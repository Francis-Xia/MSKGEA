function [Population,Fitness] = EnvironmentalSelection(Population,N,Problem,wid,state)
    %% calculate the weighted indicator value of each solution
    [n,D] = size(Population.decs);
    if state==1           % 第一个阶段：分区
        Split = SegmentSplit(Population,Problem,wid);
        Fitness = zeros(n,1);
        for i=1:2^D
            cluster = find(Split==i);
            if ~isempty(cluster)
                Fitness(cluster)  = CalFitness(Population(cluster).objs,Population(cluster).decs);
            end
        end
        Next = Fitness < 1;
        if sum(Next) < N
            [~,Rank] = sort(Fitness);
            Next(Rank(1:N)) = true;
        elseif sum(Next) > N
            Del  = Truncation(Population(Next).decs,sum(Next)-N);
            Temp = find(Next);
            Next(Temp(Del)) = false;
        end
        Population = Population(Next);
        Fitness = Fitness(Next);
    else
        %         if state == 2 % 第二个阶段：不分区进化一会
         Fitness = CalFitness(Population.objs,Population.decs);
%         Next = Fitness < 1;
        [FrontNo,MaxFNo] = NDSort(Population.objs,inf);
        Next = FrontNo < 3; 
        Population = Population(Next);
        Fitness = Fitness(Next);
    end
%     Next = Fitness < 1;
%     if sum(Next) < N
%         [~,Rank] = sort(Fitness);
%         Next(Rank(1:N)) = true;
%     elseif sum(Next) > N
%         Del  = Truncation(Population(Next).objs,sum(Next)-N);
%         Temp = find(Next);
%         Next(Temp(Del)) = false;
%     end
%     Population = Population(Next);
%     Fitness = Fitness(Next);
end

function Del = Truncation(PopDec,K)
% Select part of the solutions by truncation

N = size(PopDec,1);

%% Calculate the distance between each two solutions
%  DecDistance = inf(N);
Maxd = max(PopDec,[],1);
Mind = min(PopDec,[],1);
PopDec = (PopDec-repmat(Mind,N,1))./repmat(Maxd-Mind,N,1);

DecDistance = pdist2(PopDec,PopDec);%两个个体间的距离
DecDistance(logical(eye(length(DecDistance)))) = inf;%自己到自己的距离无限大
%     DecDistance = sort(DecDistance,2);%每一行从小到大排序，每一行就是各个点到该点的距离

%% Truncation
Del = false(1,N);
while sum(Del) < K
    Remain   = find(~Del);
    Distance = DecDistance(Remain,Remain);
    Distance = sort(Distance,2);%每一行从小到大排序，每一行就是各个点到该点的距离
    Temp     = sort(Distance,2);
    [~,Rank] = sortrows(Temp);
    Del(Remain(Rank(1))) = true;
end
end
